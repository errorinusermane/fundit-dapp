-- DropForeignKey
ALTER TABLE "public"."RewardHistory" DROP CONSTRAINT "RewardHistory_address_fkey";
